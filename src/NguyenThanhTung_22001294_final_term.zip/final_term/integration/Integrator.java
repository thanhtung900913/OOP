package final_term.integration;

public interface Integrator {
    double integrate(Polynomial polynomial, double lower, double upper);
}
