package final_term.mystudentmanager;

public class StudentManager {
    // Singleton pattern
    private static StudentManager instance;

    private MyList studentList;

    private StudentManager() {
        /* TODO */
        this.studentList = new MyLinkedList();
    }

    public static StudentManager getInstance() {
        /* TODO */
        if(instance == null){
            return new StudentManager();
        }else {
            return instance;
        }
    }

    public MyList getStudentList() {
        /* TODO */
        return this.studentList;
    }

    /**
     * Thêm sinh viên vào cuối danh sách.
     * @param student
     */
    public void append(Student student) {
        /* TODO */
        studentList.insertAtEnd(student);
    }

    /**
     * Thêm sinh viên vào danh sách ở vị trí index.
     * @param student
     * @param index
     */
    public void add(Student student, int index) {
        /* TODO */
        studentList.insertAtPosition(student, index);
    }

    /**
     * Bỏ sinh viên ở vị trí index.
     * @param index
     */
    public void remove(int index) {
        /* TODO */
        studentList.remove(index);
    }

    /**
     * Bỏ sinh viên như tham số truyền vào.
     * @param student
     */
    public void remove(Student student) {
        /* TODO */
         MyIterator iterator = studentList.iterator();
         int count = 0;
         while (iterator.hasNext()){
             Object curr = iterator.next();
             if(curr.equals((Object) (student))){
                 studentList.remove(count);
             }
             iterator.next();
             count++;
         }

    }

    /**
     * Lấy ra sinh viên ở vị trí index
     * @param index
     * @return
     */
    public Student studentAt(int index) {
        /* TODO */
        MyIterator iterator = studentList.iterator();
        Object student = null;
        int count = 0;
        while (iterator.hasNext() || count < index){
            student = iterator.next();
        }
        return (Student) student;
    }

    /**
     * Lọc ra những sinh viên có điểm trung bình trên 15 điểm.
     * @return
     */
    public MyList filterStudentsByAverageGrade() {
        /* TODO */
        MyList newL = new MyLinkedList();
        MyIterator iterator = studentList.iterator();
        while (iterator.hasNext()){
            Student curr = (Student) iterator.next();
            if(curr.getAverageGrade() > 15){
                newL.insertAtEnd(curr);
            }
        }
        return newL;
    }

    /**
     * Lọc ra những sinh viên có điểm toán trên 5 điểm.
     * @return
     */
    public MyList filterStudentsByMathGrade() {
        /* TODO */
        MyList newL = new MyLinkedList();
        MyIterator iterator = studentList.iterator();
        while (iterator.hasNext()){
            Student curr = (Student) iterator.next();
            if(curr.getMathsGrade() > 15){
                newL.insertAtEnd(curr);
            }
        }
        return newL;
    }
}
