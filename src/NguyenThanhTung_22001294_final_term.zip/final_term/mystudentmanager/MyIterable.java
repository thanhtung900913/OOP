package final_term.mystudentmanager;

public interface MyIterable {
    MyIterator iterator();
}
