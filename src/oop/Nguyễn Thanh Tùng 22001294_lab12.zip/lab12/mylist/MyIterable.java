package oop.lab12.mylist;

public interface MyIterable {
    MyIterator iterator();
}
