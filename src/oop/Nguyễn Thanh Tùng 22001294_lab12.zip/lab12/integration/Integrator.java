package oop.lab12.integration;
public interface Integrator {
    double integrate(Polynomial poly, double lower, double upper);
}
