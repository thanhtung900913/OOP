package lab4.EX2_5;

public class TestMain {
    public static void main(String[] args) {
        Customer customer = new Customer(3, "pro", 'm');
        System.out.println(customer);
        Account account = new Account(4, customer, 999.9);
        System.out.println(account);
        account.setBalance(888.8);
        System.out.println(account);
        account.deposit(52.5);
        System.out.println(account);
        account.withdraw(55.5);
        ;
        System.out.println(account);
        System.out.println("Customer's name is: " + account.getCustomerName());
    }
}
