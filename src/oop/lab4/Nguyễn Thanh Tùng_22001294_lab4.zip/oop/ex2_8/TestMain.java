package lab4.EX2_8;

import hus.oop1.lap4.mypoint.MyPoint;
import hus.oop1.lap4.myrectangleandpoint.MyRectangle;

public class TestMain {
    public static void main(String[] args) {
        int x1 = 1,y1 = 3;
        int x2 = 4, y2 = 1;

        //test conStructor
        MyRectangle myRectangle = new MyRectangle(x1,y1,x2,y2);
        System.out.println(myRectangle);
        System.out.println("the area is: " + myRectangle.getArea());
        System.out.println("the perimeter is: " + myRectangle.getPerimter());

        MyPoint d1 = new MyPoint(x1,y1);
        MyPoint d3 = new MyPoint(x2,y2);
        MyRectangle myRectangle1 = new MyRectangle(d1,d3);
        System.out.println(myRectangle1);
        System.out.println("the area is: " + myRectangle1.getArea());
        System.out.println("the perimeter is: " + myRectangle1.getPerimter());
    }
}
