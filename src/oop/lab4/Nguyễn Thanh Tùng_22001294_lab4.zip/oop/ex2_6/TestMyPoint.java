package lab4.EX2_6;

public class TestMyPoint {
    public static void main(String[] args) {
        MyPoint myPoint = new MyPoint(3,4);
        System.out.println(myPoint);
        myPoint.setX(6);
        myPoint.setY(8);
        System.out.println("x is: " +myPoint.getX());
        System.out.println("y is: " + myPoint.getY());
        myPoint.setXY(3,4);
        System.out.println(myPoint.getXY()[0]);
        System.out.println(myPoint.getXY()[1]);
        System.out.println(myPoint);
        MyPoint myPoint1 = new MyPoint(6,8);
        System.out.println(myPoint1);

        System.out.println(myPoint.distance(myPoint1));
        System.out.println(myPoint.distance());

    }
}
