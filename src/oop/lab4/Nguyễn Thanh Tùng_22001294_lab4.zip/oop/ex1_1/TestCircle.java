package lab4.oop.ex1_1;

public class TestCircle {
    public static void main(String[] args) {
    Circle circle1 = new Circle();
    System.out.println("The circle has radius of "+ circle1.getRadious()+" and area of "+circle1.getArea());
    Circle circle2 = new Circle(2.0);
    System.out.println("The circle has radius of "+ circle2.getRadious()+" and area of "+circle2.getArea());
    }

}
