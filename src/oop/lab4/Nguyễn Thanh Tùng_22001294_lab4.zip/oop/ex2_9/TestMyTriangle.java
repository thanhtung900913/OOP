package lab4.EX2_9;

import lab4.EX2_6.MyPoint;

public class TestMyTriangle {
    public static void main(String[] args) {
        int x1 = 1, y1 = 4;
        int x2 = 2, y2 = 5;
        int x3 = 3, y3 = 6;

        //test Constructor
        MyTriangle myTriangle = new MyTriangle(x1,y1,x2,y2,x3,y3);
        System.out.println(myTriangle);
        MyPoint v1 = new MyPoint(x2,y2);
        MyPoint v2 = new MyPoint(x3,y3);
        MyPoint v3 = new MyPoint(x1,y1);
        MyTriangle myTriangle1 = new MyTriangle(v1,v2,v3);
        System.out.println(myTriangle1);
        System.out.println("perimeter is: " + myTriangle.getPerimeter());
        System.out.println("the type of triangle: " + myTriangle.getType());
    }
}
