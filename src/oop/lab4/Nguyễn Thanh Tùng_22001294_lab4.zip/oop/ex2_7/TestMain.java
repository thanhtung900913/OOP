package lab4.EX2_7.;

import lab4.EX2_6.MyPoint;

public class TestMain{
    public static void main(String[] args) {
        MyPoint point1 = new MyPoint(1,2);
        MyPoint point2 = new MyPoint(4,6);
        Myline myline = new Myline(point1,point2);
        System.out.println(myline);

        //test setBegin()
        MyPoint point = new MyPoint(0,3);
        myline.setBegin(point);
        System.out.println("Begin is: " + myline.getBegin());
        // test setEnd
        MyPoint endPont = new MyPoint(7,2);
        myline.setEnd(endPont);
        System.out.println("end is: " + myline.getEnd());
        int x1 = 1, y1 = 4, x2 = 4, y2 = 0;
        Myline myline1 = new Myline(x1,y1,x2,y2);
        System.out.println(myline1);
        // test setBeginX,beginY
        myline1.setBeginX(x2);
        myline1.setBeginY(y2);
        System.out.println("Begin is: " + myline1.getBegin());
        System.out.println("beginX is: " + myline1.getBeginX());
        System.out.println("beginY is: " + myline1.getBeginY());
        //test setEndXY getEndXY
        myline1.setEndXY(x1,y1);
        System.out.println("endX is: " + myline1.getEndXY()[0]);
        System.out.println("EndY is: " + myline1.getEndXY()[1]);

        //test getLength
        System.out.println("Length is: " + myline1.getLength());

        // test getGradient
        System.out.println("the Gradient is: " + myline1.getGradient());
    }
}
