package studentmanager;

public interface StudentComparable {
    int compareTo(Student another);
}
