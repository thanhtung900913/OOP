package studentmanager;

public interface StudentComparator {
    int compare(Student left, Student right);
}
