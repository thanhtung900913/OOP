package lab6.ex1_4;

public class Test {
    public static void main(String[] args) {
    }
}
