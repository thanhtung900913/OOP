package lab6.ex2_1;

public class TestLine {
    public static void main(String[] args) {

        // test constructor

        Line l1 = new Line(0,0,3,4);
        System.out.println(l1);

        Point p1 = new Point(1,2);
        Point p2 = new Point(3,4);
        Line l2 = new Line(p1,p2);
        System.out.println(l2);

        // test get method

        System.out.println("Line begin with: "+l2.getBegin());
        System.out.println("Line end with: "+l2.getEnd());

        System.out.println("x of begin: "+l2.getBeginX());
        System.out.println("x of end: "+l2.getEndX());

        System.out.println("y of begin: "+l2.getBeginY());
        System.out.println("y of end: "+l2.getEndY());

        // test set methods

        l2.setBegin(p2);
        l2.setEnd(p1);
        System.out.println(l2);

        l2.setBeginX(10);
        l2.setBeginY(9);
        System.out.println(l2);

        l2.getEndX(0);
        l2.setEndY(8);
        System.out.println(l2);

    }
}
