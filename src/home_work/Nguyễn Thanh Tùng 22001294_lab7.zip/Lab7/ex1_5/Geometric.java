package Lab7.ex1_5;

public interface Geometric {
    double getArea();
    double getPerimeter();
}
