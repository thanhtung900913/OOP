package Lab7.ex1_5;

public interface Resizable {
    public void resize(int precent);
}
