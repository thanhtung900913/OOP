package Lab7.ex1_7;

public abstract class Animal {
    public abstract void greeting();
}
