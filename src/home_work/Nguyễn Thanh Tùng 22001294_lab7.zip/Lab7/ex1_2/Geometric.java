package Lab7.ex1_2;

public interface Geometric {
    public abstract double getArea();
    public abstract double getPerimeter();
}
