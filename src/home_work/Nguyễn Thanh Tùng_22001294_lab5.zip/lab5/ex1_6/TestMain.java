package lab5.ex1_6;

public class TestMain {
    public static void main(String[] args) {
        Ball b = new Ball(1,2,4,5,6);
        System.out.println(b.toString());
    }
}
