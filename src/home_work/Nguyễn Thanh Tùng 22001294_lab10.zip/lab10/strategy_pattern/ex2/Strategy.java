package oop.lab10.strategy_pattern.ex2;

public interface Strategy {
    int execute(int a, int b);
}
