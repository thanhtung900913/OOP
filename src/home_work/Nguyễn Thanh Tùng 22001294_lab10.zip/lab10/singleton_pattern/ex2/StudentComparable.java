package oop.lab10.singleton_pattern.ex2;

public interface StudentComparable {
    int compareTo(Student another);
}
