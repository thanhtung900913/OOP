package oop.lab10.singleton_pattern.ex2;

public interface StudentComparator {
    int compare(Student left, Student right);
}
