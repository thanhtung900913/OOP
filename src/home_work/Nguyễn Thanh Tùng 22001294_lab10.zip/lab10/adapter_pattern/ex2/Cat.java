package oop.lab10.adapter_pattern.ex2;

public interface Cat {
    public void squeak();
    public void walk();
}
