package oop.lab10.adapter_pattern.ex2;

public interface Dog {
    public void bark();
    public void walk();
}
