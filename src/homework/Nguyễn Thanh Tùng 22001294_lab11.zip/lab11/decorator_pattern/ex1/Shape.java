package oop.lab11.decorator_pattern.ex1;

public interface Shape {
    void draw();
}
