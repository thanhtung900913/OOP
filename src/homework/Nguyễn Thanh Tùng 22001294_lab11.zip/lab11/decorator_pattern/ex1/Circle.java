package oop.lab11.decorator_pattern.ex1;

public class Circle implements Shape {
    @Override
    public void draw() {
        System.out.println("Circle");
    }
}
