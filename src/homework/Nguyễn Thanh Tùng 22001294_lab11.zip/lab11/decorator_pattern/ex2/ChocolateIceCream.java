package oop.lab11.decorator_pattern.ex2;

public class ChocolateIceCream implements IceCream {
    @Override
    public String getDescription() {
        return "this is ChocolateIcream";
    }
}
