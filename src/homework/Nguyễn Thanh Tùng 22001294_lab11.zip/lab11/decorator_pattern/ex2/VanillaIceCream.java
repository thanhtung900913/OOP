package oop.lab11.decorator_pattern.ex2;

public class VanillaIceCream implements IceCream {
    @Override
    public String getDescription() {
        return "this is VanillaIceCream";
    }
}
