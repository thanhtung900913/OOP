package oop.lab11.decorator_pattern.ex2;

public interface IceCream {
    String getDescription();
}
