package oop.lab11.factory_method_pattern.ex3;

public interface Flower {
    void use();
}
