package oop.lab11.factory_method_pattern.ex3;

public class Rose implements Flower{

    @Override
    public void use() {
        System.out.println("This is Rose");
    }
}
