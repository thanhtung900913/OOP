package oop.lab11.factory_method_pattern.ex3;

public class Tulip implements Flower{
    @Override
    public void use() {
        System.out.println("this is Tulip");
    }
}
