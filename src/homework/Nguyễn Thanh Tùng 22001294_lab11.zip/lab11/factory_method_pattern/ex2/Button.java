package oop.lab11.factory_method_pattern.ex2;

public interface Button {
    void renderClick();
    void onClick();
}
