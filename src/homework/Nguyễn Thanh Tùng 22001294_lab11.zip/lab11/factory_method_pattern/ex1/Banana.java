package oop.lab11.factory_method_pattern.ex1;

public class Banana implements Fruit{
    @Override
    public void produceJuice() {
        System.out.println("Banana");
    }
}
