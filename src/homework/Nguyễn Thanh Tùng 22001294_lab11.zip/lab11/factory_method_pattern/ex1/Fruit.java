package oop.lab11.factory_method_pattern.ex1;

public interface Fruit {
    void produceJuice();
}
