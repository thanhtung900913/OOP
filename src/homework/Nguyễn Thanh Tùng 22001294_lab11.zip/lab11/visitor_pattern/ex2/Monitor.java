package lab11.Visitor.ex2;

public class Monitor implements ComputerPart{
    @Override
    public void accept(ComputerPartsDisplayVisitor visitor){
        visitor.visit(this);
    }
}
