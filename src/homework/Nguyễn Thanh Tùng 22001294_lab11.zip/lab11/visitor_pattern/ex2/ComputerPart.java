package lab11.Visitor.ex2;

public interface ComputerPart {
    public void accept(ComputerPartsDisplayVisitor visitor);
}
