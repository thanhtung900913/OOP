package lab11.Visitor.ex1;

public interface Book {
    public void accept(Visitor v);
}
