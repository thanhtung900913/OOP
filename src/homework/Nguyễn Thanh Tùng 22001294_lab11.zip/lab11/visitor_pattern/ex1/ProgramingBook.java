package lab11.Visitor.ex1;

public interface ProgramingBook extends Book {
    public String getResource();
}
