package oop.lab11.abstract_factory_pattern.ex2;

abstract class AbstractFactory{
    abstract Shape getShape(String name);
}
