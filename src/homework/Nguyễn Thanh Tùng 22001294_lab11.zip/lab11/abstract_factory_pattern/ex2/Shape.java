package oop.lab11.abstract_factory_pattern.ex2;

public interface Shape {
    public void draw();
}
