package oop.lab11.abstract_factory_pattern.ex2;

public class Square implements Shape{
    @Override
    public void draw() {
        System.out.println("Square");
    }
}
