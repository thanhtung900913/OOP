package oop.lab11.abstract_factory_pattern.ex2;

public class RoundedRectangle implements Shape{
    @Override
    public void draw() {
        System.out.println("RoundedRectangle");
    }
}
