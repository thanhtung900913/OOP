package oop.lab11.abstract_factory_pattern.ex1;

public interface Button {
    public void paint();
}
