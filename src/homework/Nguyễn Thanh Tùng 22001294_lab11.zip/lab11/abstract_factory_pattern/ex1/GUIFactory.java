package oop.lab11.abstract_factory_pattern.ex1;

public interface GUIFactory {
    public Button createButton();
    public CheckBox craeteCheckBox();
}
