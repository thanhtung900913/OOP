package oop.lab11.iterator_pattern.ex1;

public interface Iterator {
    boolean hasNext();
    Object next();
}
