package oop.lab11.iterator_pattern.ex3;

public interface Iterator {
    boolean hasNext();
    Book next();
}
