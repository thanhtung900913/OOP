package oop.lab11.iterator_pattern.ex2;

public interface ProfileIterator{
    Profile getNext();
    boolean hasMore();
}
