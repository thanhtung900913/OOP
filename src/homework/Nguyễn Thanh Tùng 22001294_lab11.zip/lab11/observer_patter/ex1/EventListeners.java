package lab11.Observer.ex1;

public interface EventListeners {
    public void update(String filename);
}
