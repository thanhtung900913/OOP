package lab11.Observer.ex2;

abstract class Observer {
    private Subject subject;
    public abstract void update();
}
